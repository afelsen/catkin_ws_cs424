Video link: https://drive.google.com/file/d/1mnLzbi2zxUpYxDT3ic8aN7YxlVlnLzx7/view?usp=sharing
The video is slightly sped up.
Time stamps:
    Grape classification - 1:20
    Pineapple classification - 3:00
    Watermelon classification - 4:20

This project was worked on by Adiel Felsen and Brendan Klayman