This project was created by Adiel Felsen and Brendan Klayman.

The generated world map is stored in the maps folder.

Mapping Video Link: https://drive.google.com/file/d/1YvqEIv_vQ5xFKEXruB-ENMK73p_h_6B6/view?usp=sharing
Navigation Video Link: https://drive.google.com/file/d/1wAF16Dt2X_sV6uzGcjkZ4Q16wFC9dRKG/view?usp=sharing